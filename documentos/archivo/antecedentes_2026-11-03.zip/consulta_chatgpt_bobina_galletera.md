# Consulta: usar una bobina de galletera como captadora de inducción

Fecha: 1 de noviembre de 2026.

Este archivo resume una conversación previa y contiene el contexto necesario para continuarla en otro chat. Quiero una segunda opinión técnica, con explicaciones claras, adecuadas a un laboratorio universitario. Revisa críticamente las sugerencias anteriores; no las tomes como resultados comprobados.

## 1. Mi experimento

Tengo un carrito que baja por un riel inclinado y transporta una captadora eléctrica. Dos bobinas grandes de Helmholtz permanecen fijas **a los costados del riel**, con eje común transversal al avance. Cambio la inclinación para cambiar la velocidad de paso por el campo y observar la señal inducida.

Quiero conseguir una señal suficientemente grande para verla en el osciloscopio. También me interesa saber si puedo usarla para medir el campo magnético. Necesito distinguir entre detectar inducción, comparar señales para distintas velocidades y medir el campo en teslas.

La geometría del simulador supone una captadora rectangular vertical en el plano longitudinal del riel, con su normal dirigida transversalmente de una bobina grande hacia la otra. También supone trayectoria por el plano medio y giro del riel alrededor del centro de las bobinas. **Esos son supuestos del modelo; falta confirmar la geometría real de la captadora y el pivote.** La ubicación lateral de las bobinas sí fue aclarada por mí.

El simulador usa un riel de 1,50 m, centro de bobinas a 0,75 m, partida desde reposo y movimiento ideal sin pérdidas. Esos datos describen el modelo y no deben interpretarse como nuevas mediciones del montaje.

## 2. Instrumento disponible

- Osciloscopio analógico Hameg HM 203-7, usando un solo canal: CH I.
- Entrada directa indicada: 1 MΩ en paralelo con 25 pF.
- Se propuso acoplamiento DC, conexión directa o sonda ×1, 5 mV/div y, si hace falta, expansión vertical ×5 para 1 mV/div efectivo.
- Base de tiempo inicial propuesta: 50 ms/div, con ajustes finos en CAL.
- Estas escalas todavía deben ajustarse con una señal real.
- No guarda trazas; se propuso grabar la pantalla en vídeo y repetir las pasadas.
- No he aportado una señal experimental, datos de ruido ni amplitudes medidas en esta conversación.

El osciloscopio mide voltaje. Si se quiere informar corriente, hace falta especificar el circuito y la conversión correspondiente. No debe confundirse la resistencia de entrada del osciloscopio con una carga externa adicional.

## 3. Modelo físico que veníamos usando

Para el movimiento ideal:

\[
a=g\sin\theta,\qquad v(s)=\sqrt{2gs\sin\theta}
\]

si la posición inicial es s = 0 y el carrito parte del reposo.

Para una captadora sencilla con N vueltas que enlazan el mismo flujo:

\[
\Phi_B(s)=\iint_{S(s)}\vec B\cdot d\vec S,
\qquad \mathcal E=-N\frac{d\Phi_B}{dt}
=-N\frac{d\Phi_B}{ds}v.
\]

En un devanado más complejo conviene usar el flujo enlazado total, con las orientaciones y conexiones correspondientes:

\[
\mathcal E=-\frac{d\lambda}{dt}.
\]

El modelo web calcula un campo suave mediante Biot–Savart y lo normaliza a un B₀ ingresado. No obtiene automáticamente B₀ de la corriente y las vueltas de las bobinas grandes. Los valores iniciales B₀ = 1 mT, 10 vueltas captadoras, R propia = 1 Ω y R carga = 1000 Ω son ejemplos, no mediciones.

No incluye núcleo ferromagnético, autoinducción, capacitancia, ruido, rozamiento, inercia de las ruedas ni frenado magnético. Por eso no representa directamente una bobina de motor con hierro.

En la geometría lateral asumida no corresponde agregar automáticamente un factor coseno de la inclinación del riel: importa el ángulo entre la normal de la captadora y el campo.

## 4. Cómo surgió la idea

Primero pregunté:

> ¿Qué pasa si en vez de usar una espira para medir el campo magnético usamos un inducido de una galletera desmontada? No sé la cantidad de espiras, pero el campo magnético que capte tiene que ser máximo.

Por «galletera» me refiero a una amoladora angular.

La respuesta anterior explicó que el rotor o inducido tiene varios devanados y un colector, de modo que no se pueden sumar todas sus vueltas como si fueran una sola bobina. Se planteó que la señal depende de orientaciones, conexiones y contactos elegidos. El hierro podría concentrar flujo, pero modifica el campo local y complica la relación entre voltaje y campo externo. No se garantizó una señal mayor.

También se aclaró que lo que induce voltaje es el **cambio de flujo**, no solamente un flujo grande. En el modelo simétrico, una captadora puede tener máximo flujo en el centro y fem instantánea nula allí; los pulsos aparecen principalmente durante la entrada y salida. Esto no es una observación experimental de mi montaje.

Después pregunté qué objetos comunes podían reemplazar la espira. Se propusieron como posibilidades para evaluar:

- Bobina de un relé electromecánico.
- Bobina de una electroválvula.
- Devanado de un transformador pequeño, especialmente si se puede separar del núcleo.
- Bobina fija del estator de una galletera o taladro.
- Recuperar alambre esmaltado y formar una bobina propia sobre un marco no magnético, contando las vueltas.

Estas opciones fueron sugerencias, no captadores ensayados. No se comprobó cuál daría más señal.

## 5. Lo que realmente tengo disponible

Luego aclaré:

> Sí tengo la bobina fija de una galletera, pero igualmente no puedo saber la cantidad de espiras que tiene.

**Esta bobina fija es la alternativa que ahora quiero evaluar. No hay que confundirla con el rotor o inducido de la primera pregunta.**

Todavía no indiqué:

- Si es solamente el arrollamiento separado del hierro o si sigue montado en el núcleo del estator.
- Si tengo una sola bobina o el conjunto de bobinas del estator.
- Su forma, dimensiones, número de terminales o conexiones internas.
- Su resistencia, inductancia, estado del aislamiento ni cantidad de vueltas.
- Cómo quedaría orientada y fijada al carrito.

No se ha aportado una fotografía.

La última respuesta indicó que, aun sin conocer las vueltas, podría ensayarla para detectar pulsos y comparar amplitudes manteniendo la misma configuración. Para convertir la señal en campo, se necesitaría caracterizar su sensibilidad mediante geometría y vueltas conocidas o una calibración apropiada. No se ha realizado esa calibración ni decidido sustituir definitivamente la espira.

## 6. Preguntas que quiero resolver ahora

1. ¿Es razonable usar la bobina fija de esta galletera como captadora móvil entre las bobinas de Helmholtz? Distingue el caso con hierro del caso sin hierro.
2. ¿Podría dar una señal más visible que una espira simple? ¿Qué datos mínimos necesitas para estimarlo, sin prometer una mejora solo porque tiene muchas vueltas?
3. ¿Cómo debo orientarla respecto del campo transversal? ¿Qué fotografías o medidas permitirían identificar su orientación efectiva y sus conexiones?
4. Si desconozco las vueltas, ¿puedo comparar voltaje y velocidad de manera útil? ¿Qué condiciones deben mantenerse y qué efectos podrían invalidar esa comparación?
5. ¿Cómo podría calibrarla para medir campo en teslas sin conocer las vueltas? Distingue una calibración en campo variable de su uso al atravesar un campo estático no uniforme.
6. ¿Qué aporta medir resistencia e inductancia? ¿Permiten determinar las vueltas por sí solas, o qué información adicional haría falta?
7. ¿Cuánto cambia la interpretación por la presencia del hierro: concentración de flujo, alteración del campo, histéresis, fuerzas sobre el carrito y respuesta temporal?
8. ¿Qué prueba inicial sencilla harías con el Hameg HM 203-7 para decidir si conviene seguir con esta bobina?
9. Con estos recursos, ¿conviene usar la bobina recuperada o fabricar una de vueltas conocidas? Explica el criterio para elegir.

Antes de hacer cálculos numéricos, identifica los datos faltantes. No supongas número de vueltas, área efectiva, permeabilidad ni voltaje esperado. Quiero aprovechar la pieza como captador pasivo desmontado, sin alimentarla desde la red eléctrica.

## 7. Fuentes mencionadas en la conversación anterior

Se incluyen para que puedas revisarlas; no sustituyen la caracterización de mi bobina:

- Máquinas de corriente continua y colector, Purdue: https://engineering.purdue.edu/KWPO/animationA/index.html
- Fabricación y calibración de bobinas captadoras, trabajo de CERN: https://arxiv.org/abs/1104.0803
- Inducción electromagnética y bobinas captadoras, recurso alojado por Brock University: https://www.physics.brocku.ca/PPLATO/h-flap/phys4_4.html
- Estructura de relés electromecánicos, Omron: https://www.ia.omron.com/data_pdf/guide/36/generalrelay_tg_e_10_5.pdf
